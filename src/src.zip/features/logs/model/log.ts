export type LogLevel = "info" | "warn" | "error";

export type AuditLog = {
  id: string;
  level: LogLevel;
  action: string; // e.g. LOGIN, CREATE_TICKET
  message: string;
  actorEmail?: string;
  createdAt: string;
};
